import React from "react";
import CardMatchingGame from "./components/CardMatchingGame";
import "./components/CardMatchingGame.css"

function App() {
  return (
    <div className="App">
      <CardMatchingGame />
    </div>
  );
}

export default App;
